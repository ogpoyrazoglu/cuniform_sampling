This version is using 1000 trajectories for cuniform and 500 for mppi, mppi variance 0.05
